Testing exports
#### Known Data Errors - test_export_table2
This data is published with the following data errors:

1. Package property, 'name' must be set.
2. Table property, 'name', must not be empty.
