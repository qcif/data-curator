Dataset explanation and changelog for SSDS_20kk

SSDS stands for Sample Synthesized Data for Steve_2021.

## Data

2021 data was obtained by Hegrid and his helpers from the forbidden jungle.


## Licence

Creative Commons Attribution (CC-BY)

## Changelog

Changes that have been applied to the data since 2012

- �usage of num will be enforced�
- �house names are to be adjusted"
- �houses are assigned based upon relation with you-know-who