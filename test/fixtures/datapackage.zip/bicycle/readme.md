Average Bicycle Counts by Day and Hour January 2016 to June 2016

Bicycle data from active transport sites installed by TMR. Data is by hour and day of the week.
